/*  Copyright (s) 2019 深圳百问网科技有限公司
 *  All rights reserved
 * 
 * 文件名称：main.c
 * 摘要�?
 *  
 * 修改历史     版本�?      Author       修改内容
 *--------------------------------------------------
 * 2020.6.6      v01        百问科技      创建文件
 *--------------------------------------------------
*/

#include "main.h"
#include "stm32f1xx_clk.h"
#include "driver_key.h"
#include "driver_led.h"
#include "driver_spi.h"
#include "driver_timer.h"
#include "driver_flash.h"

#include "driver_fsmc_lcd.h"
#include "driver_fsmc_sram.h" 

#include "driver_usart.h"

/*
    LCD include
*/
#include "lcd_function.h"
#include "XPT2046.h"

#include "get_utf_8_code.h"

extern void LCD_Show_CN_EN(uint16_t x, uint16_t y, char *pStr);
int main(void)
{    
    uint8_t i = 0;
    // 初始化HAL库函数必须要调用此函�?
    HAL_Init();

    /*
     * 系统时钟即AHB/APB时钟配置
     * 当使用内部高速时钟HSE�?MHz）配置系统时钟时，使用PLL前可以选择不分频或者二分频，我们要配置到最�?2MHz的系统频率此处当然是不分�?
     * 然后经过一个放大器，最大放大倍数�?6，我们要想得�?2MHz，此处选择9倍放大系数，�?*9=72MHz即可达到目标
    */
    SystemClock_Config();
    
    KeyInit();
    LedGpioInit();
    RLED(0);
    TimerInit();
    SPI_Init();    
    UsartInit(112500);
    FSMC_SRAM_Init();
    FSMC_LCD_Init();

    if(Get_UTF_8_File() != 0)
    {
        Error_Handler();
    }
    
    LCD_Init();
    LCD_GRAM_Scan(0);
//    XPT2046_Init();
    
    /*
        lvgl init
    */
    LCD_Clear(WHITE);
    LCD_Show_CN_EN(80, 240, (char*)"���ڰ������Ƽ�");
    while(1)
    {

    }
}

void SoftReset(void)
{
    __set_FAULTMASK(1);
    NVIC_SystemReset();
}


/*
 *  函数名：void Error_Handler(void)
 *  输入参数：无
 *  输出参数：无
 *  返回值：�?
*  函数作用：程序错误处理函数，此处暂时设为死循环，不做任何动作
*/
void Error_Handler(void)
{
    printf("Error_Handler\n\r");
    while(1)
    {
    }
}




