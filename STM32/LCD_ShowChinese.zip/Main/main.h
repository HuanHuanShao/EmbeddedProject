/*  Copyright (s) 2019 深圳百问网科技有限公司
 *  All rights reserved
 * 
 * 文件名称：main.h
 * 摘要：
 *  
 * 修改历史     版本号       Author       修改内容
 *--------------------------------------------------
 * 2020.6.6      v01        百问科技      创建文件
 *--------------------------------------------------
*/
#ifndef __MAIN_H
#define __MAIN_H

#include <stdio.h>
#include <string.h>
#include "stm32f1xx_hal.h"
#include "driver_w25qxx.h"

extern void Error_Handler(void);
extern void SoftReset(void);

#endif

