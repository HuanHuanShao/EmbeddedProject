#include "driver_fsmc_lcd.h"
#include "driver_fsmc_sram.h"

void HAL_SRAM_MspInit(SRAM_HandleTypeDef *hsram)
{
    GPIO_InitTypeDef    GPIO_InitStruct = {0};
    __HAL_RCC_FSMC_CLK_ENABLE();
    GPIOC_CLK_EN();
    GPIOD_CLK_EN();
    GPIOE_CLK_EN();
    GPIOF_CLK_EN();
    GPIOG_CLK_EN();
    
    if(hsram->Init.NSBank==FSMC_NORSRAM_BANK3)  // SRAM
    {
        GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull      = GPIO_NOPULL;
        GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_HIGH;
        
        // PDx
        GPIO_InitStruct.Pin = SRAM_GPIOD_PIN;
        HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
        
        // PEx
        GPIO_InitStruct.Pin = SRAM_GPIOE_PIN;
        HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
        
        // PFx
        GPIO_InitStruct.Pin = SRAM_GPIOF_PIN;
        HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
        
        // PGx
        GPIO_InitStruct.Pin = SRAM_GPIOG_PIN;
        HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);
    }
    else if(hsram->Init.NSBank==FSMC_NORSRAM_BANK4)  // LCD
    {
        GPIO_InitStruct.Mode      = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull      = GPIO_PULLUP;
        GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_HIGH;
        
        GPIO_InitStruct.Pin = LCD_RST_PIN;
        HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
        
        // PCx
        GPIO_InitStruct.Pin = LCD_BL_PIN;
        HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
        
        GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull      = GPIO_NOPULL;
        GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_HIGH;
    
        GPIO_InitStruct.Pin = LCD_CS_PIN;
        HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);
        
        // PDx
        GPIO_InitStruct.Pin = LCD_GPIOD_PIN;
        HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
        
        // PEx
        GPIO_InitStruct.Pin = LCD_GPIOE_PIN;
        HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
    }
}


