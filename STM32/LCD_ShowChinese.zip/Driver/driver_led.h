/*  Copyright (s) 2019 深圳百问网科技有限公司
 *  All rights reserved
 * 
 * 文件名称：driver_led.h
 * 摘要：
 *  
 * 修改历史     版本号        Author       修改内容
 *--------------------------------------------------
 * 2020.6.6      v01        百问科技      创建文件
 *--------------------------------------------------
*/

#ifndef __DRIVER_LED_H
#define __DRIVER_LED_H

#include "stm32f1xx_hal.h"

/*********************
 * 引脚宏定义
**********************/
#define R_LED_GPIO_PIN        GPIO_PIN_0
#define R_LED_GPIO_PORT       GPIOB
#define R_LED_GPIO_CLK_EN()   __HAL_RCC_GPIOB_CLK_ENABLE()

#define G_LED_GPIO_PIN        GPIO_PIN_1
#define G_LED_GPIO_PORT       GPIOB
#define G_LED_GPIO_CLK_EN()   __HAL_RCC_GPIOB_CLK_ENABLE()

#define B_LED_GPIO_PIN        GPIO_PIN_5
#define B_LED_GPIO_PORT       GPIOB
#define B_LED_GPIO_CLK_EN()   __HAL_RCC_GPIOB_CLK_ENABLE()

#define USB_MODE_Pin          GPIO_PIN_4
#define USB_MODE_GPIO_Port    GPIOE

/*********************
 * 函数宏定义
**********************/
/*
 * LED亮灭函数宏定义
*/
#define RLED(flag)        HAL_GPIO_WritePin(R_LED_GPIO_PORT, R_LED_GPIO_PIN, flag&0x1?GPIO_PIN_SET:GPIO_PIN_RESET)   
#define RLED_T()          HAL_GPIO_TogglePin(R_LED_GPIO_PORT, R_LED_GPIO_PIN)  

#define GLED(flag)        HAL_GPIO_WritePin(G_LED_GPIO_PORT, G_LED_GPIO_PIN, flag&0x1?GPIO_PIN_SET:GPIO_PIN_RESET)  
#define GLED_T()          HAL_GPIO_TogglePin(G_LED_GPIO_PORT, G_LED_GPIO_PIN)  

#define BLED(flag)        HAL_GPIO_WritePin(B_LED_GPIO_PORT, B_LED_GPIO_PIN, flag&0x1?GPIO_PIN_SET:GPIO_PIN_RESET) 
#define BLED_T()          HAL_GPIO_TogglePin(B_LED_GPIO_PORT, B_LED_GPIO_PIN)  

/*
 *  函数名：void LedGpioInit(void)
 *  输入参数：无
 *  输出参数：无
 *  返回值：无
 *  函数作用：初始化LED的引脚，配置为上拉推挽输出
*/
extern void LedGpioInit(void);

#endif


