/*  Copyright (s) 2019 深圳百问网科技有限公司
 *  All rights reserved
 * 
 * 文件名称：driver_spi.h
 * 摘要：
 *  
 * 修改历史     版本号       Author       修改内容
 *--------------------------------------------------
 * 2020.6.6      v01        百问科技      创建文件
 *--------------------------------------------------
*/
#ifndef __DRIVER_SPI_H
#define __DRIVER_SPI_H

#include "stm32f1xx_hal.h"

/************************* SPI 硬件相关定义 *************************/

#define SoftSPI_SCK_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOA_CLK_ENABLE()
#define SoftSPI_MISO_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE() 
#define SoftSPI_MOSI_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE() 
#define W25_CS_GPIO_CLK_ENABLE()            __HAL_RCC_GPIOA_CLK_ENABLE() 
#define ICM_CS_GPIO_CLK_ENABLE()            __HAL_RCC_GPIOC_CLK_ENABLE() 

#define SoftSPI_SCK_PIN                     GPIO_PIN_5
#define SoftSPI_SCK_GPIO_PORT               GPIOA
      
#define SoftSPI_MISO_PIN                    GPIO_PIN_6
#define SoftSPI_MISO_GPIO_PORT              GPIOA
        
#define SoftSPI_MOSI_PIN                    GPIO_PIN_7
#define SoftSPI_MOSI_GPIO_PORT              GPIOA

#define W25_CS_PIN                          GPIO_PIN_4               
#define W25_CS_GPIO_PORT                    GPIOA   

#define ICM_CS_PIN                          GPIO_PIN_4               
#define ICM_CS_GPIO_PORT                    GPIOC  

#define SoftSPI_CLK(level)                  { \
                                                ((level==1) ?\
                                                HAL_GPIO_WritePin(SoftSPI_SCK_GPIO_PORT, SoftSPI_SCK_PIN, GPIO_PIN_SET) : \
                                                HAL_GPIO_WritePin(SoftSPI_SCK_GPIO_PORT, SoftSPI_SCK_PIN, GPIO_PIN_RESET)); \
                                            }     

#define SoftSPI_MOSI(level)                 { \
                                                ((level==1) ?\
                                                HAL_GPIO_WritePin(SoftSPI_MOSI_GPIO_PORT, SoftSPI_MOSI_PIN, GPIO_PIN_SET) : \
                                                HAL_GPIO_WritePin(SoftSPI_MOSI_GPIO_PORT, SoftSPI_MOSI_PIN, GPIO_PIN_RESET)); \
                                            }   
#define W25_CS(level)                       { \
                                                ((level==1) ?\
                                                HAL_GPIO_WritePin(W25_CS_GPIO_PORT, W25_CS_PIN, GPIO_PIN_SET) : \
                                                HAL_GPIO_WritePin(W25_CS_GPIO_PORT, W25_CS_PIN, GPIO_PIN_RESET)); \
                                            }  
#define ICM_CS(level)                       { \
                                                ((level==1) ?\
                                                HAL_GPIO_WritePin(ICM_CS_GPIO_PORT, ICM_CS_PIN, GPIO_PIN_SET) : \
                                                HAL_GPIO_WritePin(ICM_CS_GPIO_PORT, ICM_CS_PIN, GPIO_PIN_RESET)); \
                                            } 
#define SoftSPI_MISO()                      HAL_GPIO_ReadPin(SoftSPI_MISO_GPIO_PORT, SoftSPI_MISO_PIN)
/************************* SPI 硬件相关定义结束 *************************/
/*
 *  函数名：void SPI_Init(void)
 *  输入参数：
 *  输出参数：无
 *  返回值：无
 *  函数作用：初始化SPI的四根引脚
*/
extern void SPI_Init(void);

/*
 *  函数名：uint8_t SPI_WriteReadByte(uint8_t pdata)
 *  输入参数：pdata -> 要写的一个字节数据
 *  输出参数：无
 *  返回值：读到的数据
 *  函数作用：模拟SPI读写一个字节
*/
extern uint8_t SPI_WriteReadByte(uint8_t pdata);

/*
 *  函数名：void SPI_WriteByte(uint8_t data)
 *  输入参数：data -> 要写的数据
 *  输出参数：无
 *  返回值：无
 *  函数作用：模拟SPI写一个字节
*/
extern void SPI_WriteByte(uint8_t data);

/*
 *  函数名：uint8_t SPI_ReadByte(void)
 *  输入参数：
 *  输出参数：无
 *  返回值：读到的数据
 *  函数作用：模拟SPI读一个字节
*/
extern uint8_t SPI_ReadByte(void);

#endif  //__DRIVER_SPI_H




