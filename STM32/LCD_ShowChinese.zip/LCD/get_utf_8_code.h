#ifndef __GET_UTF_CODE_H
#define __GET_UTF_CODE_H

#include "main.h"

#define CN_WIDTH             (16)
#define CN_HEIGTH            (16)

#define SD_GBK_FILE_SIZE          (256*1024)
#define SD_GBK_FILE_PATH          ("0:/Tools/GBK_H16x16.FON")

extern int Get_UTF_8_File(void);
extern uint32_t Get_GBK_FromIndex(uint8_t *gbkBuf, uint16_t index);

#endif




