#include "get_utf_8_code.h"
#include "ff.h"

FATFS   bin_fs;             /* Filesystem object */
FIL     bin_file;           /* 文件对象 */
FRESULT bin_res;            /* 文件操作结果 */
UINT    br;

static volatile uint8_t CODE_BUF[SD_GBK_FILE_SIZE] __attribute__ ((at(0x68000000)));

int Get_UTF_8_File(void)
{
    uint32_t code_sz = 0;
    bin_res = f_mount(&bin_fs, "0:", 1);
    if(bin_res == FR_OK)
    {
        printf("FATFS mount succeed\n\r");
    }
    else if(bin_res == FR_NO_FILESYSTEM)
    {
        printf("SD not inited\n\r");
        return -1;
    }
    else
    {
        printf("FATFS mount Failed\n\r");
        bin_res = f_mount(&bin_fs, "0:", 0);
        
        return 1;
    }
    
    bin_res = f_open(&bin_file, (const TCHAR*)SD_GBK_FILE_PATH, FA_READ);
    if(bin_res == FR_OK)
    {
        code_sz = bin_file.obj.objsize;
        
        if((code_sz)<SD_GBK_FILE_SIZE)
        {
            f_read(&bin_file, (void*)CODE_BUF, code_sz, &br);
            f_close(&bin_file);
            f_mount(&bin_fs, "0:", 0);
            
            return 0;
        }
    }
    else
    {
        return -1;
    }
}

uint32_t Get_GBK_FromIndex(uint8_t *gbkBuf, uint16_t index)
{
    uint16_t gbk_index = 0;
    uint8_t gbk_high_8bit = 0;
    uint8_t gbk_low_8bit = 0;
    uint32_t gbk_pos = 0;
    
    gbk_high_8bit = index>>8;
    gbk_low_8bit = index&0x00FF;
    gbk_pos = ((gbk_high_8bit - 0xA1) * 94 + (gbk_low_8bit - 0xA1)) * CN_WIDTH * CN_HEIGTH / 8;
    memcpy(gbkBuf, (uint8_t*)&CODE_BUF[gbk_pos], CN_WIDTH * CN_HEIGTH / 8);
    
    return gbk_pos;
}