#ifndef __ILI9488_H
#define __ILI9488_H

#include "main.h"

extern void ILI9488_Init(void);

#endif /* __ILI9341_H */



